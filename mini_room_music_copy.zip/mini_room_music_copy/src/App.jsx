import { useRef } from 'react';
import Spline from '@splinetool/react-spline';

export default function App() {
  const photo = useRef();

  function onLoad(spline) {
    const obj = spline.findObjectById('7bd47bd8-f484-4457-8ffb-2bbfae7269ec');
    photo.current = obj;
  }

  function moveObj() {
    console.log(photo.current);
    photo.current.position.x += 10;
  }

  function onMouseHover(e) {
    if (e.target.name === 'click_me') {
      console.log('I have been clicked!');
    }
  }

  return (
    <div className="spline-container">
      <Spline
        scene="https://prod.spline.design/WLnUBpnVfnLZIl9g/scene.splinecode"
        onLoad={onLoad}
        onMouseHover={onMouseHover}
        className="spine"
      />
      <button type="button" onClick={moveObj} className="move-cube-btn">
        Move Cube
      </button>
    </div>
  );
}



